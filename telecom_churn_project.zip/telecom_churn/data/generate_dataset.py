import pandas as pd
import numpy as np

np.random.seed(42)
n = 7043

# Demographics
customer_id = [f'CUST-{str(i).zfill(5)}' for i in range(1, n+1)]
gender = np.random.choice(['Male', 'Female'], n)
senior_citizen = np.random.choice([0, 1], n, p=[0.84, 0.16])
partner = np.random.choice(['Yes', 'No'], n, p=[0.48, 0.52])
dependents = np.random.choice(['Yes', 'No'], n, p=[0.30, 0.70])

# Tenure (months) - bimodal: new and long-term customers
tenure = np.concatenate([
    np.random.randint(1, 12, int(n*0.30)),
    np.random.randint(12, 36, int(n*0.25)),
    np.random.randint(36, 72, n - int(n*0.30) - int(n*0.25))
])
np.random.shuffle(tenure)

# Services
phone_service = np.random.choice(['Yes', 'No'], n, p=[0.90, 0.10])
multiple_lines = np.where(phone_service == 'No', 'No phone service',
                 np.random.choice(['Yes', 'No'], n, p=[0.42, 0.58]))
internet_service = np.random.choice(['DSL', 'Fiber optic', 'No'], n, p=[0.34, 0.44, 0.22])

def internet_addon(internet_service, yes_p=0.45):
    return np.where(internet_service == 'No', 'No internet service',
            np.random.choice(['Yes', 'No'], n, p=[yes_p, 1-yes_p]))

online_security   = internet_addon(internet_service, 0.28)
online_backup     = internet_addon(internet_service, 0.34)
device_protection = internet_addon(internet_service, 0.34)
tech_support      = internet_addon(internet_service, 0.29)
streaming_tv      = internet_addon(internet_service, 0.38)
streaming_movies  = internet_addon(internet_service, 0.39)

# Contract & Billing
contract = np.random.choice(['Month-to-month', 'One year', 'Two year'], n, p=[0.55, 0.21, 0.24])
paperless_billing = np.random.choice(['Yes', 'No'], n, p=[0.59, 0.41])
payment_method = np.random.choice(
    ['Electronic check', 'Mailed check', 'Bank transfer (automatic)', 'Credit card (automatic)'],
    n, p=[0.34, 0.23, 0.22, 0.21]
)

# Charges
monthly_charges = np.where(
    internet_service == 'No',
    np.random.uniform(18, 30, n),
    np.where(internet_service == 'DSL',
             np.random.uniform(25, 70, n),
             np.random.uniform(45, 110, n))
)
monthly_charges = np.round(monthly_charges, 2)
total_charges = np.round(monthly_charges * tenure + np.random.normal(0, 5, n), 2)
total_charges = np.maximum(total_charges, monthly_charges)

# Churn logic — realistic probabilities
churn_prob = np.zeros(n)
churn_prob += np.where(contract == 'Month-to-month', 0.25, 0)
churn_prob += np.where(contract == 'One year', 0.05, 0)
churn_prob += np.where(internet_service == 'Fiber optic', 0.12, 0)
churn_prob += np.where(tenure < 6, 0.15, 0)
churn_prob += np.where(tenure > 48, -0.10, 0)
churn_prob += np.where(online_security == 'No', 0.08, 0)
churn_prob += np.where(tech_support == 'No', 0.07, 0)
churn_prob += np.where(payment_method == 'Electronic check', 0.06, 0)
churn_prob += np.where(monthly_charges > 80, 0.05, 0)
churn_prob += np.where(senior_citizen == 1, 0.04, 0)
churn_prob += np.where(partner == 'No', 0.03, 0)
churn_prob = np.clip(churn_prob, 0.02, 0.85)
churn = np.where(np.random.random(n) < churn_prob, 'Yes', 'No')

df = pd.DataFrame({
    'customerID': customer_id,
    'gender': gender,
    'SeniorCitizen': senior_citizen,
    'Partner': partner,
    'Dependents': dependents,
    'tenure': tenure,
    'PhoneService': phone_service,
    'MultipleLines': multiple_lines,
    'InternetService': internet_service,
    'OnlineSecurity': online_security,
    'OnlineBackup': online_backup,
    'DeviceProtection': device_protection,
    'TechSupport': tech_support,
    'StreamingTV': streaming_tv,
    'StreamingMovies': streaming_movies,
    'Contract': contract,
    'PaperlessBilling': paperless_billing,
    'PaymentMethod': payment_method,
    'MonthlyCharges': monthly_charges,
    'TotalCharges': total_charges,
    'Churn': churn
})

df.to_csv('telecom_churn/data/telecom_churn.csv', index=False)
print(f"Dataset created: {df.shape[0]} rows, {df.shape[1]} columns")
print(f"Churn rate: {(df['Churn']=='Yes').mean()*100:.1f}%")
print(df.head())
